<?php
include 'function/function.php'; //Connection to function
manage(); //Function name for add
?>
<!DOCTYPE html>
<html>
<head>
	<title>Procedural CRUD</title>
	<link rel="icon" type="text/css" href="assets/logo.jpg">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body style="background-color: #504a4a;">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-uppercase" style="color:white;"><h3><b>Procedural - Create, Read, Update and Delete</b><hr></h3></div>
			<div class="col-md-3">
				<div class="panel panel-default">
					<div class="panel-heading">Add User</div>
					<div class="panel-body">
						<form method="post">
							<div class="form-group">
								<label>Name</label>
								<input type="text" class="form-control" name="name" style="border-radius: 0px;" required>
							</div>
							<div class="form-group">
								<label>Address</label>
								<textarea  class="form-control" name="address" style="border-radius: 0px; resize: none;" required></textarea>
							</div>
							<div class="form-group">
								<label>Email</label>
								<input type="email" class="form-control" name="email" style="border-radius: 0px;" required>
							</div>
							<div class="form-group">
								<label>Contact Number</label>
								<input type="number" class="form-control" name="contact" style="border-radius: 0px;" required>
							</div>
							<div class="form-group">
								<button class="btn btn-default btn-sm btn-block" name="btn-add" style="border-radius: 0px;">Submit</button>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-heading">User Lists</div>
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-hover">
								<thead>
									<tr>
										<th style="width:10px;">#</th>
										<th>Name</th>
										<th>Address</th>
										<th>Email</th>
										<th>Contact</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$sql = "SELECT * FROM user_tbl";
									$query = mysqli_query($con, $sql);
									$i = 1;
									while ($row = mysqli_fetch_assoc($query)) { ?>
										<tr>
											<td><?=$i++?>.</td>
											<td><?=$row['name']?></td>
											<td><textarea rows="2" style="resize: none;" disabled><?=$row['address']?></textarea></td>
											<td><?=$row['email']?></td>
											<td><?=$row['contact']?></td>
											<td>
												<form method="post">
													<input type="hidden" name="user_id" value=<?=$row['user_id']?>>
													<a href="edit.php?user_id=<?=$row['user_id']?>" name="btn-edit" class="btn btn-default btn-sm" style="border-radius: 0px;">Edit</a>
													<button type="submit" name="btn-delete" onclick="return confirm('Do you want to delete this data?')" class="btn btn-default btn-sm" style="border-radius: 0px;">Delete</button>
												</form>
											</td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12 text-center" style="color:white;">
			<hr>&copy; 2019 | Arjeth Pascual | Procedural - Create, Read, Update and Delete
		</div>
	</div>
</body>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</html>