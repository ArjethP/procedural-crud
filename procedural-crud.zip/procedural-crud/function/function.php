<?php

	include 'config.php';

	function manage() {
		global $con;
		if (isset($_POST['btn-add'])) { // Add Function

		$name = mysqli_real_escape_string($con, $_POST['name']);
		$address = mysqli_real_escape_string($con, $_POST['address']);
		$email = mysqli_real_escape_string($con, $_POST['email']);
		$contact = mysqli_real_escape_string($con, $_POST['contact']);
		$sqlCheck = "SELECT * FROM user_tbl WHERE email = '$email'";
		$queryCheck = mysqli_query($con,$sqlCheck);
		$result = mysqli_num_rows($queryCheck);
		if ($result > 0) {
			echo "<script>alert('Email already exist.')</script>";
		} else {
			if ($name == '' || $address == '' || $email == '' || $contact == '') {
				echo "<script>alert('All fields are required.')</script>";
			} else {
				// uncword(variable) *automatically capitalize the first letter of each word*
				$name = ucwords($name);
				$address = ucwords($address);
				$sql = "INSERT INTO user_tbl (name, address, email, contact) VALUES ('$name', '$address', '$email', '$contact')";
				$query = mysqli_query($con, $sql);
				if ($query) {
					echo "<script>alert('Successfully added.')</script>";
				} else {
					echo "<script>alert('Error occured in adding data.')</script>";
				}
			}
		}
		echo "<script>location.href='index.php'</script>";

		} elseif (isset($_POST['btn-update'])) { // Update Function

			$user_id = mysqli_real_escape_string($con,$_POST['user_id']);
			$name = mysqli_real_escape_string($con, $_POST['name']);
			$address = mysqli_real_escape_string($con, $_POST['address']);
			$email = mysqli_real_escape_string($con, $_POST['email']);
			$contact = mysqli_real_escape_string($con, $_POST['contact']);
			$sqlCheck = "SELECT * FROM user_tbl WHERE email = '$email'";
			$queryCheck = mysqli_query($con,$sqlCheck);
			$result = mysqli_num_rows($queryCheck);
			$rows = mysqli_fetch_assoc($queryCheck);
			if ($result > 0) {
				if ($rows['user_id'] == $user_id){
					if ($name == '' || $address == '' || $email == '' || $contact == '') {
						echo "<script>alert('All fields are required.')</script>";
					} else {
						// uncword(variable) *automatically capitalize the first letter of each word*
						$name = ucwords($name);
						$address = ucwords($address);
						$sql = "UPDATE user_tbl SET name = '$name', address = '$address', email = '$email', contact = '$contact'";
						$query = mysqli_query($con, $sql);
						if ($query) {
							echo "<script>alert('Successfully updated.')</script>";
						} else {
							echo "<script>alert('Error occured in adding data.')</script>";
						}
					}
				} else {
					echo "<script>alert('Email already exist.')</script>";
				}
			} else {
				if ($name == '' || $address == '' || $email == '' || $contact == '') {
					echo "<script>alert('All fields are required.')</script>";
				} else {
					// uncword(variable) *automatically capitalize the first letter of each word*
					$name = ucwords($name);
					$address = ucwords($address);
					$sql = "UPDATE user_tbl SET name = '$name', address = '$address', email = '$email', contact = '$contact'";
					$query = mysqli_query($con, $sql);
					if ($query) {
						echo "<script>alert('Successfully updated.')</script>";
					} else {
						echo "<script>alert('Error occured in updating data.')</script>";
					}
				}
			}
			echo "<script>location.href='edit.php?user_id=".$rows['user_id']."'</script>";

		} elseif (isset($_POST['btn-delete'])) {
			$user_id = mysqli_real_escape_string($con,$_POST['user_id']);
			$sql = "DELETE FROM user_tbl WHERE user_id = '$user_id'";
			$query = mysqli_query($con, $sql);
			if ($query) {
				echo "<script>alert('Successfully removed.')</script>";
			} else {
				echo "<script>alert('Error occured in removing data.')</script>";
			}
		}
	}